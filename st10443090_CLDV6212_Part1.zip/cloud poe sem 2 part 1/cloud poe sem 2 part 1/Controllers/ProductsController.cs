﻿using cloud_poe_sem_2_part_1.Models;
using cloud_poe_sem_2_part_1.Services;
using Microsoft.AspNetCore.Mvc;

namespace cloud_poe_sem_2_part_1.Controllers
{
    public class ProductsController : Controller
    {
        private readonly ProductTableService _productService;

        public ProductsController(ProductTableService productService)
        {
            _productService = productService;
        }

        public async Task<IActionResult> Index()
        {
            var products = await _productService.GetAllProductsAsync();
            return View(products);
        }
    }
}
