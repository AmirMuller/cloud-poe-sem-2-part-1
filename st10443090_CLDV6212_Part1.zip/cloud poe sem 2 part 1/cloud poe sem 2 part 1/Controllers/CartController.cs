﻿using cloud_poe_sem_2_part_1.Models;
using cloud_poe_sem_2_part_1.Services;
using Microsoft.AspNetCore.Mvc;

namespace cloud_poe_sem_2_part_1.Controllers
{
    public class CartController : Controller
    {
        private readonly CartRepository _cartRepo;
        private readonly AzureQueueService _queueService;

        public CartController(CartRepository cartRepo, AzureQueueService queueService)
        {
            _cartRepo = cartRepo;
            _queueService = queueService;
        }

        public async Task<IActionResult> Index()
        {
            var userId = User.Identity?.Name ?? "Guest";
            var cart = await _cartRepo.GetCartAsync(userId);
            return View(cart);
        }

        [HttpPost]
        public async Task<IActionResult> Add(string productId, int quantity)
        {
            var userId = User.Identity?.Name ?? "Guest";
            await _cartRepo.AddToCartAsync(userId, productId, quantity);
            return RedirectToAction("Index", "Cart");
        }

        [HttpPost]
        public async Task<IActionResult> Remove(string productId)
        {
            var userId = User.Identity?.Name ?? "Guest";
            await _cartRepo.RemoveFromCartAsync(userId, productId);
            return RedirectToAction("Index", "Cart");
        }

        [HttpPost]
        public async Task<IActionResult> Checkout()
        {
            var userId = User.Identity?.Name ?? "Guest";
            var cartItems = await _cartRepo.GetCartAsync(userId);

            if (!cartItems.Any())
            {
                TempData["Error"] = "Your cart is empty. Nothing to checkout.";
                return RedirectToAction("Index", "Cart");
            }

            foreach (var item in cartItems)
            {
                var order = new OrderMessage
                {
                    UserId = userId,
                    ProductId = item.ProductId,
                    Quantity = item.Quantity
                };

                await _queueService.EnqueueMessageAsync(order);

                // Remove from cart
                await _cartRepo.RemoveFromCartAsync(userId, item.ProductId);
            }

            TempData["Success"] = "Your order has been placed successfully!";
            return RedirectToAction("Index", "Products");
        }
    }
}
