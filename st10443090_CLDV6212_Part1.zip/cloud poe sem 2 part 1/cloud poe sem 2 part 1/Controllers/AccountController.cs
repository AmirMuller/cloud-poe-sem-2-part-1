﻿using cloud_poe_sem_2_part_1.Models;
using cloud_poe_sem_2_part_1.Services;
using Microsoft.AspNetCore.Mvc;
using System.Security.Cryptography;
using System.Text;

namespace cloud_poe_sem_2_part_1.Controllers
{
    public class AccountController : Controller
    {
        private readonly UserTableService _userService;

        public AccountController(UserTableService userService)
        {
            _userService = userService;
        }

        [HttpGet]
        public IActionResult Register() => View();

        [HttpPost]
        public async Task<IActionResult> Register(string username, string email, string password)
        {
            var existingUser = await _userService.GetUserByUsernameAsync(username);
            if (existingUser != null)
            {
                ViewBag.Error = "Username already exists.";
                return View();
            }

            var hashedPassword = HashPassword(password);
            var user = new UserEntity
            {
                Username = username,
                Email = email,
                PasswordHash = hashedPassword
            };

            await _userService.AddUserAsync(user);
            return RedirectToAction("Login");
        }

        [HttpGet]
        public IActionResult Login() => View();

        [HttpPost]
        public async Task<IActionResult> Login(string username, string password)
        {
            var user = await _userService.GetUserByUsernameAsync(username);

            if (user != null && VerifyPassword(password, user.PasswordHash))
            {
                // Save username in session
                HttpContext.Session.SetString("Username", user.Username);

                return RedirectToAction("Index", "Home");
            }

            ViewBag.Error = "Invalid credentials.";
            return View();
        }

        public IActionResult Logout()
        {
            HttpContext.Session.Clear(); // remove user session
            return RedirectToAction("Index", "Home");
        }

        private string HashPassword(string password)
        {
            using var sha256 = SHA256.Create();
            var bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
            return Convert.ToBase64String(bytes);
        }

        private bool VerifyPassword(string password, string storedHash)
        {
            return HashPassword(password) == storedHash;
        }
    }
}
