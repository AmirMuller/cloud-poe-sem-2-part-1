using cloud_poe_sem_2_part_1.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllersWithViews();
builder.Services.AddHttpContextAccessor();
builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromHours(1);
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
});

// User service
builder.Services.AddSingleton<UserTableService>(sp =>
{
    var config = sp.GetRequiredService<IConfiguration>();
    return new UserTableService(config["AzureStorage:ConnectionString"], config["AzureStorage:TableName"]);
});

// Product service
builder.Services.AddSingleton<ProductTableService>(sp =>
{
    var config = sp.GetRequiredService<IConfiguration>();
    return new ProductTableService(config["AzureStorage:ConnectionString"], "Products");
});

// Cart service
builder.Services.AddSingleton<CartRepository>(sp =>
{
    var config = sp.GetRequiredService<IConfiguration>();
    return new CartRepository(config["AzureStorage:ConnectionString"], "Cart");
});

// Queue service
builder.Services.AddSingleton<AzureQueueService>(sp =>
{
    var config = sp.GetRequiredService<IConfiguration>();
    return new AzureQueueService(config["AzureStorage:ConnectionString"], "ordersqueue");
});

// Background worker (order processor, optional)
builder.Services.AddHostedService<OrderProcessor>();

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseSession();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
