﻿using Azure.Data.Tables;
using cloud_poe_sem_2_part_1.Models;

namespace cloud_poe_sem_2_part_1.Services;

public class CartRepository
{
    private readonly TableClient _cartTable;

    public CartRepository(string connectionString, string tableName)
    {
        var serviceClient = new TableServiceClient(connectionString);
        _cartTable = serviceClient.GetTableClient(tableName);
        _cartTable.CreateIfNotExists();
    }

    public async Task AddToCartAsync(string userId, string productId, int quantity)
    {
        var entity = new TableEntity(userId, productId)
        {
            { "ProductId", productId },
            { "Quantity", quantity },
            { "AddedAt", DateTime.UtcNow }
        };

        await _cartTable.UpsertEntityAsync(entity);
    }

    public async Task<List<CartItem>> GetCartAsync(string userId)
    {
        var items = new List<CartItem>();
        var query = _cartTable.QueryAsync<TableEntity>(e => e.PartitionKey == userId);

        await foreach (var entity in query)
        {
            items.Add(new CartItem
            {
                PartitionKey = entity.PartitionKey,
                RowKey = entity.RowKey,
                ProductId = entity.GetString("ProductId"),
                Quantity = entity.GetInt32("Quantity") ?? 1,
                AddedAt = entity.GetDateTime("AddedAt") ?? DateTime.UtcNow
            });
        }

        return items;
    }

    public async Task RemoveFromCartAsync(string userId, string productId)
    {
        await _cartTable.DeleteEntityAsync(userId, productId);
    }
}
