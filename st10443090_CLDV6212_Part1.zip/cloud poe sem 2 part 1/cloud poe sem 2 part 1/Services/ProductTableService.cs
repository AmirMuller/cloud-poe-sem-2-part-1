﻿using Azure.Data.Tables;
using cloud_poe_sem_2_part_1.Models;

namespace cloud_poe_sem_2_part_1.Services;

public class ProductTableService
{
    private readonly TableClient _tableClient;

    public ProductTableService(string connectionString, string tableName)
    {
        var serviceClient = new TableServiceClient(connectionString);
        _tableClient = serviceClient.GetTableClient(tableName);
        _tableClient.CreateIfNotExists();
    }

    public async Task<List<ProductEntity>> GetAllProductsAsync()
    {
        var products = _tableClient.Query<ProductEntity>();
        return products.ToList();
    }
}
