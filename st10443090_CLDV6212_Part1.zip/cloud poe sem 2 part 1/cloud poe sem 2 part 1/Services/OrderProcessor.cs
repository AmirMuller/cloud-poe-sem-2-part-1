﻿using cloud_poe_sem_2_part_1.Models;
using System.Text.Json;

namespace cloud_poe_sem_2_part_1.Services;

public class OrderProcessor : BackgroundService
{
    private readonly AzureQueueService _queueService;
    private readonly ProductTableService _productService;

    public OrderProcessor(AzureQueueService queueService, ProductTableService productService)
    {
        _queueService = queueService;
        _productService = productService;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        while (!stoppingToken.IsCancellationRequested)
        {
            var message = await _queueService.DequeueMessageAsync();
            if (message != null)
            {
                var order = JsonSerializer.Deserialize<OrderMessage>(message);
                if (order != null)
                {
                    // TODO: decrement stock in ProductTableService
                    // await _productService.UpdateStockAsync(order.ProductId, order.Quantity);
                }
            }

            await Task.Delay(2000, stoppingToken); //poll every 2 seconds
        }
    }
}
