﻿using Azure.Storage.Queues;
using System.Text.Json;

namespace cloud_poe_sem_2_part_1.Services;

public class AzureQueueService
{
    private readonly QueueClient _queueClient;

    public AzureQueueService(string connectionString, string queueName)
    {
        _queueClient = new QueueClient(connectionString, queueName);
        _queueClient.CreateIfNotExists();
    }

    public async Task EnqueueMessageAsync<T>(T message)
    {
        var payload = JsonSerializer.Serialize(message);
        await _queueClient.SendMessageAsync(
            Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(payload)));
    }

    public async Task<string?> DequeueMessageAsync()
    {
        var response = await _queueClient.ReceiveMessageAsync();
        if (response.Value != null)
        {
            string decoded = System.Text.Encoding.UTF8.GetString(
                Convert.FromBase64String(response.Value.Body.ToString()));
            await _queueClient.DeleteMessageAsync(response.Value.MessageId, response.Value.PopReceipt);
            return decoded;
        }
        return null;
    }
}
