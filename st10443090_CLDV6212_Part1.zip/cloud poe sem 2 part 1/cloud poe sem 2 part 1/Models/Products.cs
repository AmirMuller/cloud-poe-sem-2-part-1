﻿using Azure;
using Azure.Data.Tables;

namespace cloud_poe_sem_2_part_1.Models;

public class ProductEntity : ITableEntity
{
    public string PartitionKey { get; set; } = "PRODUCT";
    public string RowKey { get; set; } = Guid.NewGuid().ToString();

    public string Name { get; set; }
    public string Description { get; set; }
    public decimal Price { get; set; } // store as string or decimal
    public string ImageUrl { get; set; } // blob URL

    // required
    public DateTimeOffset? Timestamp { get; set; }
    public ETag ETag { get; set; }
}

