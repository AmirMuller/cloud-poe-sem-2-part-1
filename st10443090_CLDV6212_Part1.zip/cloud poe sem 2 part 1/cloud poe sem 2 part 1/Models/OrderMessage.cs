﻿namespace cloud_poe_sem_2_part_1.Models;

public class OrderMessage
{
    public string UserId { get; set; }
    public string ProductId { get; set; }
    public int Quantity { get; set; }
    public DateTime OrderedAt { get; set; } = DateTime.UtcNow;
}
