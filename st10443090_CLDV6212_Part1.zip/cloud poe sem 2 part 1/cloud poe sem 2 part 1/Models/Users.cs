﻿using Azure;
using Azure.Data.Tables;

namespace cloud_poe_sem_2_part_1.Models;

public class UserEntity : ITableEntity
{
    public string PartitionKey { get; set; } = "USER"; //partition
    public string RowKey { get; set; } = Guid.NewGuid().ToString(); // user id

    public string Username { get; set; }
    public string PasswordHash { get; set; } // hashed text
    public string Email { get; set; }

    // required props by Azure Tables
    public DateTimeOffset? Timestamp { get; set; }
    public ETag ETag { get; set; }
}
