﻿namespace cloud_poe_sem_2_part_1.Models;

public class CartItem
{
    public string PartitionKey { get; set; } // User ID
    public string RowKey { get; set; }       // Product ID
    public string ProductId { get; set; }
    public int Quantity { get; set; }
    public DateTime AddedAt { get; set; }
}

 
